package com.example.web_services;

class User {


    public String firstname;
    public String lastname;
}
