package com.usmanisolutions.pdf_file_uploader_try_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ViewUploadsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_uploads);
    }
}
