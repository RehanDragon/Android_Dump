package com.usmanisolutions.authentication_using_firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignupActivity extends AppCompatActivity {
    private EditText inputEmail,inputPassword,firstname,lastname,fathersname,retypeemail,retypepassword;
    private Button btnSignIn,btnSignup,btnResetPassword;
    private ProgressBar progressBar;
    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        auth=FirebaseAuth.getInstance();

        btnSignIn=(Button) findViewById(R.id.sign_in_button);
        btnSignup=(Button) findViewById(R.id.sign_up_button);
        btnResetPassword=(Button) findViewById(R.id.button_reset_password);
        inputPassword=(EditText)findViewById(R.id.password);
        progressBar=(ProgressBar) findViewById(R.id.progressBar);
        inputEmail=(EditText) findViewById(R.id.email);

        firstname=(EditText) findViewById(R.id.first_name);
        lastname=(EditText) findViewById(R.id.last_name);
        fathersname=(EditText) findViewById(R.id.fathers_name);
        retypeemail=(EditText) findViewById(R.id.retype_email);
        retypepassword=(EditText) findViewById(R.id.retype_password);




        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignupActivity.this,ResetPasswordActivity.class));
            }
        });



        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent go_to_Login_Screen = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(go_to_Login_Screen);
                finish();
            }
        });




        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*logics in input wala variable pa lagain ge*/
                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();
                String first_name=firstname.getText().toString().trim();
                String last_name = lastname.getText().toString().trim();
                String fathers_name = fathersname.getText().toString().trim();
                String retype_email = retypeemail.getText().toString().trim();
                String retype_password = retypepassword.getText().toString().trim();
                /*

It is simply a set of utility functions to do operations on String objects.
 In fact, the whole class doesn't have any instance fields or methods.
  Everything is static. Consider it like a container to group functions with a text-based semantic.
   Many of them could have been methods of a String inherited class or CharSequence inherited class. For example you can do:


TextUtils.indexOf(string, char)
which is the same of doing

string.indexOf(char);





one of the uses of textUtils is for example lets say you have a string "apple,banana,orange,pinapple,mango" which doesnt fit inside

 a given width it can be converted to "Apple, banana, 2 more".


* */

                if(TextUtils.isEmpty(email))
                {
                    Toast.makeText(SignupActivity.this, "Enter email add", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(! (retype_email.equals(email) )  )
                {
                    Toast.makeText(SignupActivity.this, "Entered Email not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(fathers_name))
                {
                    Toast.makeText(SignupActivity.this, "Enter Fathers name", Toast.LENGTH_SHORT).show();
                return;
                }

                if(TextUtils.isEmpty(last_name))
                {
                    Toast.makeText(SignupActivity.this, "Enter last Name", Toast.LENGTH_SHORT).show();
                }

                if(TextUtils.isEmpty(password/*jis variable pa hum na input store kr waya ha wo wala variable rekha ha */))
                {
                    Toast.makeText(SignupActivity.this, "Enter password", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(! (retype_password.equals(password)  ) )
                {
                    //return nai likhain ga to application ka flow yehan pa a k ruk gye ga
                    Toast.makeText(SignupActivity.this, "Password dont match", Toast.LENGTH_SHORT).show();
                    return;
                }


                if(TextUtils.isEmpty(first_name))
                {
                    Toast.makeText(SignupActivity.this, "Enter first name", Toast.LENGTH_SHORT).show();
                }

                if(password.length() <6)
                {
                    Toast.makeText(SignupActivity.this, "Password too short", Toast.LENGTH_SHORT).show();

                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

                auth.createUserWithEmailAndPassword(email,password)
                        .addOnCompleteListener(SignupActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override

                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Toast.makeText(SignupActivity.this, "createUserWithEmail:onComplete :"+task.isSuccessful(), Toast.LENGTH_SHORT).show();

                                progressBar.setVisibility(View.GONE);

                                if(! ( task.isSuccessful()  ) )
                                {
                                    Toast.makeText(SignupActivity.this, "Authentication failed"+task.getException(), Toast.LENGTH_SHORT).show();
                                }

                                else
                                {

//wapsi main activity pa ja reha ha
                                    Intent i = new Intent(SignupActivity.this,LoginActivity.class);
                                    startActivity(i);
                                    //Toast.makeText(SignupActivity.this, "pakistan", Toast.LENGTH_SHORT).show();
                               }

                            }
                        });
            }
        });










    }

    @Override
    protected void onResume() {
        super.onResume();
    progressBar.setVisibility(View.GONE);
    }
}
