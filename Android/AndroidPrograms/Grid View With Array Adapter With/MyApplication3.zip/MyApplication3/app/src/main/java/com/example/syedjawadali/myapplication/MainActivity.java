package com.example.syedjawadali.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

public class MainActivity extends AppCompatActivity {
 GridView gridView ;
 String [] items = {"Apple" , "mango" , "Banana" , "beery" , "graps" , "watermallon"};
 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);






    }
}


