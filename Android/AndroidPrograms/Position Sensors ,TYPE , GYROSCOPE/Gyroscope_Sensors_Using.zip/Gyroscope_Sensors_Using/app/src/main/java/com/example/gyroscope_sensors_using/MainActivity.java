package com.example.gyroscope_sensors_using;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    Sensor gyroscopeSensor;
    SensorEventListener gyroscopeSensorListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*

        To get access to any hardware sensor, you need a SensorManager object.
         To create it,
         use the getSystemService() method of your Activity class and pass the SENSOR_SERVICE constant to it.


SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        * */

        SensorManager sensorManager= (SensorManager) getSystemService(SENSOR_SERVICE);

        gyroscopeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);


        /*
   Step 2: Register a Listener
Creating a listener for the gyroscope sensor is no different from creating one for the proximity sensor.

 While registering it, however, you must make sure that its sampling frequency is very high. Therefore,

instead of specifying a polling interval in microseconds, I suggest you use the SENSOR_DELAY_NORMAL constant.

         */


         gyroscopeSensorListener = new SensorEventListener() {
             @Override
             public void onSensorChanged(SensorEvent sensorEvent) {


                 if(sensorEvent.values[2] > 0.5f)
                 {
                     getWindow().getDecorView().setBackgroundColor(Color.BLUE);
                 }
                 else if(sensorEvent.values[2]  < -0.5f  )
                 {
                     getWindow().getDecorView().setBackgroundColor(Color.YELLOW);
                 }

                 else
                     {
                         getWindow().getDecorView().setBackgroundColor(Color.WHITE);
                     }






             }

             @Override
             public void onAccuracyChanged(Sensor sensor, int accuracy) {

             }
         };

         //Register the listener

        sensorManager.registerListener(gyroscopeSensorListener,gyroscopeSensor,SensorManager.SENSOR_DELAY_NORMAL);

        /*

        Step 3: Use the Raw Data
The gyroscope sensor's raw data consists of three float values,
specifying the angular velocity of the device along the X, Y, and Z axes.
The unit of each value is radians per second. In case of anticlockwise rotation along any axis,
the value associated with that axis will be positive.
In case of clockwise rotation, it will be negative.
Because we are currently interested only in rotation along the Z-axis,
 we'll be working only with the third element in the values array of the SensorEvent object.
 If it's more than 0.5f,we can, to a large extent,
 be sure that the rotation is anticlockwise, and set the background color to blue. Similarly, if it's less than -0.5f,
  we can set the background color to yellow.
        * */



    }
}
