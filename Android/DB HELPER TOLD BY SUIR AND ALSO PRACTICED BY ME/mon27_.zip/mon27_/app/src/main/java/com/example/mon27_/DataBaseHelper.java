package com.example.mon27_;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String dbname = "mydata.db";
    private static final String tablename = "info";
    private static final String col_id = "id";
    private static final String col_name = "name";
    private static final String col_father_name = "father name";





    public DataBaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context,dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not Exists " +tablename+"" +
                "(id int(11) primary key AutoIncrement not null ,name varchar(255) , fahter_name varchar(255))");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists "+tablename);
        onCreate(db);


    }

    public boolean insert(String n ,String f  ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", n);
        cv.put("fahter_name" , f);
        long res = db.insert(tablename , null , cv);
        if(res == 1){

            return false;

        }
        else
            return true;


    }

}
