package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      lv=  (ListView) findViewById(R.id.listV);

      String [] list_of_items ={"item 1","item 2","item 3","item 4","item 5","item 6","item 6","item 7","item 8","item 9","item 10","item 11"};

      //  Remember Array adapter come in generic

        //Array Adapter Of Type String
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1/*i was getting error here because i had selected wrong layout sample */,list_of_items);


        lv.setAdapter(adapter);
    }
}
