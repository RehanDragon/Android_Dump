package com.example.calculator_with_seperate_class_and_methods_and_2_input_and_4_operations;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // this is the template for custom button  calculator



    TextView num1,num2,ans;
    EditText ed_txt_num1 ,ed_txt_num2,ed_txt_ans;
    Button add,sub,mul,div;


    MyFunctions obj1 ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = (TextView) findViewById(R.id.txt_num1);
        num2 = (TextView) findViewById(R.id.txt_num2);
        ans = (TextView) findViewById(R.id.txt_ans);


        ed_txt_num1= (EditText) findViewById(R.id.ed_txt_num1);
        ed_txt_num2= (EditText) findViewById(R.id.ed_txt_num2);
        ed_txt_ans= (EditText) findViewById(R.id.ed_txt_ans);


        add = (Button) findViewById(R.id.btn_add);
        sub = (Button) findViewById(R.id.btn_sub);
        mul = (Button) findViewById(R.id.btn_mul);
        div = (Button) findViewById(R.id.btn_div);








            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    obj1= new MyFunctions();

                    double number1 = Double.parseDouble(ed_txt_num1.getText().toString());
                    double number2 = Double.parseDouble(ed_txt_num2.getText().toString());

                    double adder = obj1.add(number1,number2);
// String.valueOf()    krna zaruri ha  , ku ka huma output String main chiyia ha , jub hum na calculation perform kare yane ka addition perform
                    // to humare pas wo value integer main convert  ho gye ,  to jub wo value humare pas integer main convert hue ,
                    // to aus ko duabra huma String main convert kerna pra ga
                    // ager hum aisa nai krain ga to humare application unfortunately stop ho gye ge

                    ed_txt_ans.setText(String.valueOf(adder));

                    //Add aub false ho gye ga ku ka ,condition true ho gye add ke. to aub aur mazed add na kro



                }
            });



            sub.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    obj1= new MyFunctions();

                    double number1 = Double.parseDouble(ed_txt_num1.getText().toString());
                    double number2 = Double.parseDouble(ed_txt_num2.getText().toString());

                    double substractor = obj1.sub(number1,number2);
// String.valueOf()    krna zaruri ha  , ku ka huma output String main chiyia ha , jub hum na calculation perform kare yane ka addition perform
                    // to humare pas wo value integer main convert  ho gye ,  to jub wo value humare pas integer main convert hue ,
                    // to aus ko duabra huma String main convert kerna pra ga
                    // ager hum aisa nai krain ga to humare application unfortunately stop ho gye ge

                    ed_txt_ans.setText(String.valueOf(substractor));

                    //Sub aub false ho gye ga ku ka ,condition true ho gye sub ke. to aub aur mazed sub na kro



                }
            });








            mul.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    obj1= new MyFunctions();

                    double number1 = Double.parseDouble(ed_txt_num1.getText().toString());
                    double number2 = Double.parseDouble(ed_txt_num2.getText().toString());

                    double multiplicator = obj1.mul(number1,number2);
// String.valueOf()    krna zaruri ha  , ku ka huma output String main chiyia ha , jub hum na calculation perform kare yane ka addition perform
                    // to humare pas wo value integer main convert  ho gye ,  to jub wo value humare pas integer main convert hue ,
                    // to aus ko duabra huma String main convert kerna pra ga
                    // ager hum aisa nai krain ga to humare application unfortunately stop ho gye ge

                    ed_txt_ans.setText(String.valueOf(multiplicator));

                    //Mul aub false ho gye ga ku ka ,condition true ho gye Mul ke. to aub aur mazed Mul na kro



                }
            });




            div.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    obj1= new MyFunctions();

                    double number1 = Double.parseDouble(ed_txt_num1.getText().toString());
                    double number2 = Double.parseDouble(ed_txt_num2.getText().toString());

                    double devider = obj1.div(number1,number2);
// String.valueOf()    krna zaruri ha  , ku ka huma output String main chiyia ha , jub hum na calculation perform kare yane ka addition perform
                    // to humare pas wo value integer main convert  ho gye ,  to jub wo value humare pas integer main convert hue ,
                    // to aus ko duabra huma String main convert kerna pra ga
                    // ager hum aisa nai krain ga to humare application unfortunately stop ho gye ge

                    ed_txt_ans.setText(String.valueOf(devider));

                    //Div aub false ho gye ga ku ka ,condition true ho gye Div ke. to aub aur mazed Div na kro



                }
            });
















    }
}


class MyFunctions
{
    public static double add(double num1, double num2){

        return num1+num2;

    }

    public static double sub(double num1 , double num2)
    {
        return num1-num2;
    }


    public static double mul(double num1, double num2)
    {

        return num1*num2;

    }

    public static double div(double num1, double num2)
    {
        return num1/num2;
    }







}
