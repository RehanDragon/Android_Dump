package com.example.tryingtodo_addition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private Button click;
private EditText input_value1;
private EditText input_value2;


private TextView Output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    click =(Button) findViewById(R.id.button);

    input_value1 =(EditText) findViewById(R.id.editText1);
    input_value2 =  (EditText)  findViewById(R.id.editText2);

    Output = findViewById(R.id.output);









// click mera button ha aur button k ander coding hote ha aur aus pa logic define hote ha
    click.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {


            //pehla string ke value ko integer main convert kia phir aus ka bad
            // integer value ko wapse String main convert kr dia


            /**
             * toString()
             *
             * Returns a stream of {@code int} zero-extending the {@code char} values
             * from this sequence.  Any char which maps to a <a
             * href="{@docRoot}/java/lang/Character.html#unicode">surrogate code
             * point</a> is passed through uninterpreted.
             *
             * <p>If the sequence is mutated while the stream is being read, the
             * result is undefined.
             *
             * @return an IntStream of char values from this sequence
             * @since 1.8
             */


            int a = Integer.parseInt(   input_value1.getText().toString()       );


            int b= Integer.parseInt(   input_value2.getText().toString()      );

            int c=a+b;
// String.valueOf()    krna zaruri ha  , ku ka huma output String main chiyia ha , jub hum na calculation perform kare yane ka addition perform
            // to humare pas wo value integer main convert  ho gye ,  to jub wo value humare pas integer main convert hue ,
            // to aus ko duabra huma String main convert kerna pra ga
            // ager hum aisa nai krain ga to humare application unfortunately stop ho gye ge
            Output.setText(String.valueOf(c) );


        }
    });



    }
}
