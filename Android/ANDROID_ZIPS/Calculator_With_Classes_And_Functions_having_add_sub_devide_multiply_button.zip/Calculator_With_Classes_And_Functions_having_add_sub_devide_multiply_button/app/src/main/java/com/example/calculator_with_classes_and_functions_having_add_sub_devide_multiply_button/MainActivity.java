package com.example.calculator_with_classes_and_functions_having_add_sub_devide_multiply_button;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


  private EditText num1,num2;
  private   TextView ans;
  private   Button addition,substraction,multiplication,division;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//Never Forget to do find view by id



        addition=(Button) findViewById(R.id.Add);
        substraction=(Button) findViewById(R.id.Sub);
        multiplication=(Button) findViewById(R.id.Mul);
        division=(Button) findViewById(R.id.Div);


        num1= (EditText) findViewById(R.id.ed_txt_num1);
        num2= (EditText) findViewById(R.id.ed_txt_num2);

        ans=(TextView) findViewById(R.id.txt_ans);




        addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyFunctions obj = new MyFunctions();
                double n1= Double.parseDouble(num1.getText().toString()  ) ;
                double n2= Double.parseDouble(num2.getText().toString()  ) ;

            double adder=   obj.add(n1,n2) ;

            ans.setText(String.valueOf(adder));

            }
        });



        substraction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyFunctions obj = new MyFunctions();
                double n1= Double.parseDouble(num1.getText().toString()  ) ;
                double n2= Double.parseDouble(num2.getText().toString()  ) ;

                double substractor=    obj.sub(n1,n2) ;

                ans.setText(String.valueOf(substractor) );/*String.valueOf setText() method k ander aye ga*/

            }
        });



        multiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyFunctions obj = new MyFunctions();
                double n1= Double.parseDouble(num1.getText().toString()  ) ;
                double n2= Double.parseDouble(num2.getText().toString()  ) ;

                double multiplicator=    obj.mul(n1,n2) ;

                ans.setText(String.valueOf(multiplicator));

            }
        });

        division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyFunctions obj = new MyFunctions();
                double n1= Double.parseDouble(num1.getText().toString()  ) ;
                double n2= Double.parseDouble(num2.getText().toString()  ) ;

                double dividor=    obj.div(n1,n2) ;

                ans.setText(String.valueOf(dividor));

            }
        });
















    }
}


 class MyFunctions
{
    public static double add(double input1, double input2)
    {
        return input1+input2;
    }

    public static double sub(double input1 , double input2)
    {
        return input1-input2;
    }

    public static double mul(double input1 , double input2)
    {
        return input1*input2;
    }

    public static double div(double input1 , double input2)
    {
        return input1/input2;
    }


}
