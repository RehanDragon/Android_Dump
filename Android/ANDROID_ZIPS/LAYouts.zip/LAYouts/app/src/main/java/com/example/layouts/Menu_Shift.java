package com.example.layouts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Menu_Shift extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__shift);
    }
}
