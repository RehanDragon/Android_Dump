package com.example.get_put_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.lang.reflect.Array;

public class Second extends AppCompatActivity {

    private TextView nam ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        nam =(TextView) findViewById(R.id.name);

        Intent in = getIntent();
        String name = in.getStringExtra("namekey");

        nam.setText(name);


    }
}
