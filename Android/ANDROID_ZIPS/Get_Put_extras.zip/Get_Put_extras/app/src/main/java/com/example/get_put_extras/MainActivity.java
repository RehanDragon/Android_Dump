package com.example.get_put_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText name1 ;
    private Button btn ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = (Button) findViewById(R.id.btn);
        name1  =(EditText) findViewById(R.id.name);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name  = name1.getText().toString();
                Intent  intent = new Intent(getApplicationContext(),Second.class);
                // name , mera pas aik tareka sa key ha jesa roll number hota ha , roll number sa hum person ko call kerta hain
                intent.putExtra("namekey" , name);

                startActivity(intent);




            }
        });





    }
}
