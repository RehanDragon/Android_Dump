package com.example.intents_more_practice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Screen3 extends AppCompatActivity {


    TextView text_on_screen_3;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen3);

    text_on_screen_3 = (TextView) findViewById(R.id.txt_new_activity_text);



    }
}
