package com.example.intents_more_practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Screen2 extends AppCompatActivity {

    TextView my_text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);


        my_text = (TextView) findViewById(R.id.txt_new_activity_text);

        my_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent screen2__intent_connecting_screen3 = new Intent(getApplicationContext() , Screen3.class);


                startActivity(screen2__intent_connecting_screen3);


            }
        });




    }
}
