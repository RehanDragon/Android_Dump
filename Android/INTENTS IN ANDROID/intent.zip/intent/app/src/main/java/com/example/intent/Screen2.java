package com.example.intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Screen2 extends AppCompatActivity {

    private TextView t ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);
     t=(TextView) findViewById(R.id.txt_);
     t.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Intent screen = new Intent(getApplicationContext(), Screen3.class );
             startActivity(screen);
         }
     });

    }
}
