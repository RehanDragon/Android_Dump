package com.example.practicing_intents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button MyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyButton = (Button) findViewById(R.id.btn_MyButton);

        MyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent screen = new Intent(getApplicationContext(),Screen_2.class);

                startActivity(screen);


            }
        });



    }
}
